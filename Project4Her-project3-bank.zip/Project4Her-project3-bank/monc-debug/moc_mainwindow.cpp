/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.7.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../monc/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.7.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[29];
    char stringdata0[574];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 21), // "on_buttonBack_pressed"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 21), // "on_buttonStop_pressed"
QT_MOC_LITERAL(4, 56, 22), // "on_buttonStart_pressed"
QT_MOC_LITERAL(5, 79, 30), // "on_buttonPinCorrection_pressed"
QT_MOC_LITERAL(6, 110, 27), // "on_buttonPinConfirm_pressed"
QT_MOC_LITERAL(7, 138, 22), // "on_buttonSaldo_pressed"
QT_MOC_LITERAL(8, 161, 24), // "on_buttonOpnemen_pressed"
QT_MOC_LITERAL(9, 186, 21), // "on_buttonSnel_pressed"
QT_MOC_LITERAL(10, 208, 20), // "on_button100_pressed"
QT_MOC_LITERAL(11, 229, 19), // "on_button20_pressed"
QT_MOC_LITERAL(12, 249, 20), // "on_button200_pressed"
QT_MOC_LITERAL(13, 270, 19), // "on_button50_pressed"
QT_MOC_LITERAL(14, 290, 20), // "on_button500_pressed"
QT_MOC_LITERAL(15, 311, 23), // "on_buttonAnders_pressed"
QT_MOC_LITERAL(16, 335, 32), // "on_buttonBedragCorrectie_pressed"
QT_MOC_LITERAL(17, 368, 30), // "on_buttonBedragConfirm_pressed"
QT_MOC_LITERAL(18, 399, 23), // "on_buttonBonYes_pressed"
QT_MOC_LITERAL(19, 423, 22), // "on_buttonBonNo_pressed"
QT_MOC_LITERAL(20, 446, 26), // "on_buttonSkipDebug_pressed"
QT_MOC_LITERAL(21, 473, 4), // "nuid"
QT_MOC_LITERAL(22, 478, 29), // "on_buttonRestartDebug_pressed"
QT_MOC_LITERAL(23, 508, 13), // "insertPincode"
QT_MOC_LITERAL(24, 522, 3), // "key"
QT_MOC_LITERAL(25, 526, 17), // "insertAnderBedrag"
QT_MOC_LITERAL(26, 544, 10), // "closeEvent"
QT_MOC_LITERAL(27, 555, 12), // "QCloseEvent*"
QT_MOC_LITERAL(28, 568, 5) // "event"

    },
    "MainWindow\0on_buttonBack_pressed\0\0"
    "on_buttonStop_pressed\0on_buttonStart_pressed\0"
    "on_buttonPinCorrection_pressed\0"
    "on_buttonPinConfirm_pressed\0"
    "on_buttonSaldo_pressed\0on_buttonOpnemen_pressed\0"
    "on_buttonSnel_pressed\0on_button100_pressed\0"
    "on_button20_pressed\0on_button200_pressed\0"
    "on_button50_pressed\0on_button500_pressed\0"
    "on_buttonAnders_pressed\0"
    "on_buttonBedragCorrectie_pressed\0"
    "on_buttonBedragConfirm_pressed\0"
    "on_buttonBonYes_pressed\0on_buttonBonNo_pressed\0"
    "on_buttonSkipDebug_pressed\0nuid\0"
    "on_buttonRestartDebug_pressed\0"
    "insertPincode\0key\0insertAnderBedrag\0"
    "closeEvent\0QCloseEvent*\0event"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  129,    2, 0x0a /* Public */,
       3,    0,  130,    2, 0x0a /* Public */,
       4,    0,  131,    2, 0x0a /* Public */,
       5,    0,  132,    2, 0x0a /* Public */,
       6,    0,  133,    2, 0x0a /* Public */,
       7,    0,  134,    2, 0x0a /* Public */,
       8,    0,  135,    2, 0x0a /* Public */,
       9,    0,  136,    2, 0x0a /* Public */,
      10,    0,  137,    2, 0x0a /* Public */,
      11,    0,  138,    2, 0x0a /* Public */,
      12,    0,  139,    2, 0x0a /* Public */,
      13,    0,  140,    2, 0x0a /* Public */,
      14,    0,  141,    2, 0x0a /* Public */,
      15,    0,  142,    2, 0x0a /* Public */,
      16,    0,  143,    2, 0x0a /* Public */,
      17,    0,  144,    2, 0x0a /* Public */,
      18,    0,  145,    2, 0x0a /* Public */,
      19,    0,  146,    2, 0x0a /* Public */,
      20,    1,  147,    2, 0x0a /* Public */,
      22,    0,  150,    2, 0x0a /* Public */,
      23,    1,  151,    2, 0x0a /* Public */,
      25,    1,  154,    2, 0x0a /* Public */,
      26,    1,  157,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QByteArray,   21,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QByteArray,   24,
    QMetaType::Void, QMetaType::QByteArray,   24,
    QMetaType::Void, 0x80000000 | 27,   28,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_buttonBack_pressed(); break;
        case 1: _t->on_buttonStop_pressed(); break;
        case 2: _t->on_buttonStart_pressed(); break;
        case 3: _t->on_buttonPinCorrection_pressed(); break;
        case 4: _t->on_buttonPinConfirm_pressed(); break;
        case 5: _t->on_buttonSaldo_pressed(); break;
        case 6: _t->on_buttonOpnemen_pressed(); break;
        case 7: _t->on_buttonSnel_pressed(); break;
        case 8: _t->on_button100_pressed(); break;
        case 9: _t->on_button20_pressed(); break;
        case 10: _t->on_button200_pressed(); break;
        case 11: _t->on_button50_pressed(); break;
        case 12: _t->on_button500_pressed(); break;
        case 13: _t->on_buttonAnders_pressed(); break;
        case 14: _t->on_buttonBedragCorrectie_pressed(); break;
        case 15: _t->on_buttonBedragConfirm_pressed(); break;
        case 16: _t->on_buttonBonYes_pressed(); break;
        case 17: _t->on_buttonBonNo_pressed(); break;
        case 18: _t->on_buttonSkipDebug_pressed((*reinterpret_cast< QByteArray(*)>(_a[1]))); break;
        case 19: _t->on_buttonRestartDebug_pressed(); break;
        case 20: _t->insertPincode((*reinterpret_cast< QByteArray(*)>(_a[1]))); break;
        case 21: _t->insertAnderBedrag((*reinterpret_cast< QByteArray(*)>(_a[1]))); break;
        case 22: _t->closeEvent((*reinterpret_cast< QCloseEvent*(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QWidget::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 23;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
